/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_add_header("Accept-Language", 
		"en-US,en;q=0.5");

/*Correlation comment - Do not change!  Original value='143198.03564196HDzfHtipQfiDDDDDttVQtptQDHf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=userSession",
		"TagName=input",
		"Extract=value",
		"Name=userSession",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$ct=application/x-protobuf&key=AIzaSyC7jsptDS3am4tPx4r3nxis7IMjBc5Dovo&$httpMethod=POST&$req=ChUKE25hdmNsaWVudC1hdXRvLWZmb3gaJwgFEAEaGwoNCAUQBhgBIgMwMDEwARD8nx4aAhgKu21J6CICIAIoARonCAEQARobCg0IARAGGAEiAzAwMTABENjGExoCGAqpD4D2IgIgAigBGicIAxABGhsKDQgDEAYYASIDMDAxMAEQh78TGgIYCsZ8kq4iAiACKAEaJwgHEAEaGwoNCAcQBhgBIgMwMDEwARDsyBMaAhgKrCMMjCICIAIoARolCAkQARoZCg0ICRAGGAEiAzAwMTABECQaAhgK80oTOSICIAIoAQ==", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	return 0;
}
