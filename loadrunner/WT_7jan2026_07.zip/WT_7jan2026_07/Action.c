Action()
{

	lr_start_transaction("check flights_01");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	lr_think_time(69);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("check flights_01",LR_AUTO);

	lr_think_time(27);

	web_image("Itinerary Button", 
		"Alt=Itinerary Button", 
		"Snapshot=t4.inf", 
		LAST);

	return 0;
}
